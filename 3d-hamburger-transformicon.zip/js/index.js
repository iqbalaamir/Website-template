setTimeout(function() {
	$('html').removeClass('init');
}, 1000);
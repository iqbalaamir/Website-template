A Pen created at CodePen.io. You can find this one at https://codepen.io/bennettfeely/pen/rymVPV.

 Idea by vlbrsk
From dribbble "Hamburger Transformation"
https://dribbble.com/shots/3353380-Hamburger-transformation